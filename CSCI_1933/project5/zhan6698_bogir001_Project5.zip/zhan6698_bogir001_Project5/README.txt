Group members names:
Alice Zhang zhan6698 ID: 5524184
Ruchitha Bogireddi bogir001 ID: 5589215

Group members worked on all of the classes and methods together.

Unzip the files contained in the zip file to a folder. Compile the java files.

There is no new assumptions. We followed the project guidelines.

There is no additional features in our project.

There are no known bugs or defects in the program. 

Outside resources we used are listed below: 
https://runestone.academy/runestone/books/published/pythonds/SortSearch/Hashing.html
We used this article for inspiration on different methods to hash keys. We found out about the folding method for our hash3 function and our hash2 function was inspired by the mid-square method (though we didn't follow that format exactly)

We got help from the TAs and class materials.


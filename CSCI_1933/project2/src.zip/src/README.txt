 Alice Zhang zhan6698 5524184
 Ruchitha Bogireddi bogir001 5589215
 Contributions: Each partner contributed to each component of the project equally.
 How to compile:
 Unzip the files contained in the project2 zip file folder
 Compile the java files, the driver method is in Game.java
 Assumptions: There are no new assumptions added to the project. We followed the project guidelines.
    Be did implement the following helper functions:
    place_boats()
    chooseValidPosition()
    spacesAreAvailable()
    updateBoardAndBoatCells()
    boats_remaining()
    inBounds()
    print()
    get_shots()
    get_rows()
    get_cols()
    main() for Board.java is for our testing
 Additional features: No additional features
 Any known bugs or defects: No known bugs
 Any outside sources:
    Noah helped us--THANK YOU!!!
    Class materials

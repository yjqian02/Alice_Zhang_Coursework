# Alice Zhang's Coursework and Projects

All projects were completed in University of Minnesota, Twin Cities coureses unless otherwise stated. 

Projects are sorted by course and labed as follows:

CSCI 1133: Introduction to Programming Principles in Python

CSCI 1933: Introduction to Data Structures & Algorithms

CSCI 2021: Introduction to Machine Architecture

CSCI 2041: Advanced Programming Principles

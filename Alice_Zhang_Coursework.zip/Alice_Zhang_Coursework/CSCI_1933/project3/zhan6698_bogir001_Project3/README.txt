Group members names: 
Alice Zhang zhan6698 ID: 5524184
Ruchitha Bogireddi bogir001 ID: 5589215

Group members worked on all of the classes and methods together. 

Unzip the files contained in the zip file to a folder. Compile the java files. 

We assume the user is using a unheaded linked list. We followed the project guidelines. 

Additional features that our project had: we implemented a helper function called check_isSorted(). 

There are no known bugs or defects in the program.Outside resources were not used in this project. We got help from the TAs and class materials. 


  
Group memebers names: 
Alice Zhang zhan6698
Ruchitha Bogireddi bogir001

Group members worked on all of the classes and methods together. 

Unzip the files contained in the project 1 zip file to a folder. Compile the java files; the driver method is in the FractalDrawer class. 


There are no new assumptions added to this project. We followed the project guidelines. There are no known bugs or defects in the program. 
Outside resources were not used in this project. We got help from the TAs and class materials. 